# Andrey Spivak — Portfolio (Next.js + Tailwind)

This project is ready to open in StackBlitz **or** run locally.

## Open in StackBlitz (no install)

1. Go to https://stackblitz.com/ (logged-in).
2. Click **Create Project** → **Upload Project**.
3. Upload the ZIP of this folder.
4. Wait for install. Then click **Open in New Tab** to preview the app.
5. Edit `pages/index.js` → the FILMOGRAPHY list to add real titles, years, and poster URLs.

## Run locally

```bash
npm install
npm run dev
# open http://localhost:3000
```

- Place your logo as `/public/IMG_3840.PNG` (already included).
- Replace poster placeholders with real poster URLs when you have them.
