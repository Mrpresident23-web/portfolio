import Head from "next/head";
import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Link as LinkIcon, ExternalLink, Mail, Download } from "lucide-react";

// ====== Filmography seeded from your provided Kinopoisk links ======
const FILMOGRAPHY = [
  {
    title: "Project 1",
    year: "",
    role: "Data Manager",
    image: "/poster-placeholder.png",
    sources: [{ label: "Kinopoisk", url: "https://www.kinopoisk.ru/series/1207237/" }],
    notes: ""
  },
  {
    title: "Project 2",
    year: "",
    role: "Data Manager",
    image: "/poster-placeholder.png",
    sources: [{ label: "Kinopoisk", url: "https://www.kinopoisk.ru/series/2000034/" }],
    notes: ""
  },
  {
    title: "Project 3",
    year: "",
    role: "Data Manager",
    image: "/poster-placeholder.png",
    sources: [{ label: "Kinopoisk", url: "https://www.kinopoisk.ru/series/4714996/" }],
    notes: ""
  },
  {
    title: "Project 4",
    year: "",
    role: "Data Manager",
    image: "/poster-placeholder.png",
    sources: [{ label: "Kinopoisk", url: "https://www.kinopoisk.ru/film/5394675/" }],
    notes: ""
  },
  {
    title: "Project 5",
    year: "",
    role: "Data Manager",
    image: "/poster-placeholder.png",
    sources: [{ label: "Kinopoisk", url: "https://www.kinopoisk.ru/series/5394456/" }],
    notes: ""
  },
  {
    title: "Project 6",
    year: "",
    role: "Data Manager",
    image: "/poster-placeholder.png",
    sources: [{ label: "Kinopoisk", url: "https://www.kinopoisk.ru/film/5368403/" }],
    notes: ""
  },
  {
    title: "Project 7",
    year: "",
    role: "Data Manager",
    image: "/poster-placeholder.png",
    sources: [{ label: "Kinopoisk", url: "https://www.kinopoisk.ru/film/6099781/" }],
    notes: ""
  },
];

const ROLES = ["All", ...Array.from(new Set(FILMOGRAPHY.map(f => f.role)))];

export default function Home() {
  const [query, setQuery] = useState("");
  const [role, setRole] = useState("All");
  const filtered = useMemo(() => {
    return FILMOGRAPHY.filter(item => {
      const q = query.toLowerCase();
      const matchQuery = [item.title, String(item.year), item.role, item.notes || ""].join(" ").toLowerCase().includes(q);
      const matchRole = role === "All" || item.role === role;
      return matchQuery && matchRole;
    });
  }, [query, role]);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      <Head>
        <title>Andrey Spivak — Portfolio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <Header />
      <main className="mx-auto max-w-6xl px-4 md:px-6 lg:px-8 pb-24">
        <Intro />
        <Controls query={query} setQuery={setQuery} role={role} setRole={setRole} />
        <FilmographyList items={filtered} />
      </main>
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-neutral-950/60 bg-neutral-950/90 border-b border-neutral-800">
      <div className="mx-auto max-w-6xl px-4 md:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src="/IMG_3840.PNG"
            alt="Data Manager Logo"
            className="h-10 w-10 rounded-full object-contain bg-neutral-900 p-1 shadow-sm"
          />
          <div className="leading-tight">
            <div className="font-semibold tracking-tight">Andrey Spivak</div>
            <div className="text-xs text-neutral-400">Logger • Playback Operator • Data Manager</div>
          </div>
        </div>
        <nav className="flex items-center gap-3 text-sm">
          <a href="#filmography" className="hover:text-white text-neutral-300">Filmography</a>
          <a href="#contact" className="hover:text-white text-neutral-300">Contact</a>
        </nav>
      </div>
    </header>
  );
}

function Intro() {
  return (
    <section className="pt-12 md:pt-20">
      <div className="grid md:grid-cols-3 gap-6 md:gap-10 items-start">
        <div className="md:col-span-2">
          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-3xl md:text-5xl font-semibold tracking-tight"
          >
            Andrey Spivak
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.5 }}
            className="mt-3 text-lg text-neutral-300"
          >
            I work in the film industry as a <span className="text-neutral-100">Logger</span>, <span className="text-neutral-100">Playback Operator</span>, and <span className="text-neutral-100">Data Manager</span>. I build reliable on‑set video and data workflows, instant review pipelines, and clean handoffs to post.
          </motion.p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="mailto:andrey@example.com"
              className="inline-flex items-center gap-2 rounded-2xl bg-neutral-800 hover:bg-neutral-700 px-4 py-2 text-sm shadow-sm"
              id="contact"
            >
              <Mail className="h-4 w-4" /> Email
            </a>
            <a
              href="#"
              className="inline-flex items-center gap-2 rounded-2xl bg-neutral-800 hover:bg-neutral-700 px-4 py-2 text-sm shadow-sm"
            >
              <Download className="h-4 w-4" /> Download CV (PDF)
            </a>
          </div>
        </div>
        <div>
          <ul className="grid gap-2 text-sm text-neutral-300">
            <li className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-neutral-500"/> Video assist & playback rigs</li>
            <li className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-neutral-500"/> Live logging, clip notes, continuity</li>
            <li className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-neutral-500"/> Data wrangling & verified backups</li>
            <li className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-neutral-500"/> Dailies prep & post handoff</li>
          </ul>
        </div>
      </div>
    </section>
  );
}

function Controls({ query, setQuery, role, setRole }) {
  return (
    <section className="mt-10">
      <div className="flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search title, year, role…"
            className="w-full rounded-2xl bg-neutral-900 border border-neutral-800 px-10 py-2 outline-none focus:ring-2 focus:ring-neutral-600"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto">
          {ROLES.map(r => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`px-3 py-1.5 rounded-2xl border text-sm whitespace-nowrap ${role === r ? "bg-white text-black border-white" : "bg-neutral-950 border-neutral-800 text-neutral-300 hover:bg-neutral-900"}`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

function FilmographyList({ items }) {
  return (
    <section id="filmography" className="mt-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl md:text-2xl font-semibold tracking-tight">Filmography</h2>
        <span className="text-sm text-neutral-400">{items.length} {items.length === 1 ? "credit" : "credits"}</span>
      </div>
      <AnimatePresence mode="popLayout">
        {items.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-neutral-400 text-sm"
          >
            No results. Try a different search or role filter.
          </motion.div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {items.map((item, idx) => (
              <motion.article
                key={item.sources?.[0]?.url || item.title + idx}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
                className="rounded-2xl overflow-hidden bg-neutral-900 border border-neutral-800 shadow-sm"
              >
                <div className="aspect-[16/9] overflow-hidden">
                  <img
                    src={item.image}
                    alt={`${item.title} preview`}
                    className="h-full w-full object-cover hover:scale-[1.02] transition-transform"
                    loading="lazy"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold leading-tight">{item.title || "Untitled Project"}</h3>
                  <p className="text-sm text-neutral-400 mt-1">{item.year || "—"} • {item.role}</p>
                  {item.notes && (
                    <p className="text-sm text-neutral-300 mt-2">{item.notes}</p>
                  )}
                  {item.sources?.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {item.sources.map((s, i) => (
                        <a
                          key={s.url + i}
                          href={s.url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="inline-flex items-center gap-1 rounded-xl border border-neutral-700 px-2.5 py-1 text-xs text-neutral-200 hover:bg-neutral-800"
                        >
                          <LinkIcon className="h-3.5 w-3.5" /> {s.label} <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}

function Footer() {
  return (
    <footer className="mt-20 border-t border-neutral-800/60">
      <div className="mx-auto max-w-6xl px-4 md:px-6 lg:px-8 py-8 text-sm text-neutral-400 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          © {new Date().getFullYear()} Andrey Spivak. All rights reserved.
        </div>
        <div className="flex items-center gap-4">
          <a href="#filmography" className="hover:text-neutral-200">Back to top</a>
          <span className="text-neutral-700">•</span>
          <span>Built with Next.js & Tailwind</span>
        </div>
      </div>
    </footer>
  );
}
